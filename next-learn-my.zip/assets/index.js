import style_antd from './antd.less';

export {
    style_antd
}